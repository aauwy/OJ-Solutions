#include<stdio.h>
int main(){int a,b,c=1,t;scanf("%d",&t);while(t--){scanf("%d%d",&a,&b);printf("Case %d: %d\n",c++,a+b);}return 0;}
